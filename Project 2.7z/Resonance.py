ResonancePlot1 = Resonance(x0,v0,0) # This takes significantly longer than all the other functions to run.
ResonancePlot2 = Resonance(x0,v0,0.25)
ResonancePlot3 = Resonance(x0,v0,4.827)
ResonancePlot4 = Resonance(x0,v0,9.654)

plt.plot(ResonancePlot1[:,0],ResonancePlot1[:,1],"-b",label="Undamped")
plt.plot(ResonancePlot2[:,0],ResonancePlot2[:,1],"C1",label="Light damping")
plt.plot(ResonancePlot3[:,0],ResonancePlot3[:,1],"-g",label="Critical damping")
plt.plot(ResonancePlot4[:,0],ResonancePlot4[:,1],"-r",label="Heavy damping")
plt.ylabel("Maximum amplitude (m)")
plt.xlabel("Forcing angular frequency (rad/s)")
plt.show()