EulerPlot2 = EulerMethod(x0,v0,0.01,10000)
AnalyticalPlot = Analytical(x0,v0,0.001,100000)

plt.plot(EulerPlot2[:,0],EulerPlot2[:,1],"-g", label = "Euler method") # phase space plot
plt.plot(AnalyticalPlot[:,0],AnalyticalPlot[:,1],"-r", label = "Analytical solution")
plt.legend(loc='upper left')
plt.ylabel("Velocity (m/s)")
plt.xlabel("Displacement from equilibrium (m)")
plt.show()