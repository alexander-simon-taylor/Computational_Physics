EulerPlot1 = EulerMethod(x0,v0,0.1,1000)
EulerHamiltonian1 = Hamiltonian(EulerPlot1)

EulerPlot2 = EulerMethod(x0,v0,0.01,10000)
EulerHamiltonian2 = Hamiltonian(EulerPlot2)

EulerPlot3 = EulerMethod(x0,v0,0.001,100000)
EulerHamiltonian3 = Hamiltonian(EulerPlot3)

EulerPlot4 = EulerMethod(x0,v0,0.0001,1000000)
EulerHamiltonian4 = Hamiltonian(EulerPlot4)

EulerPlot5 = EulerMethod(x0,v0,0.00001,10000000)
EulerHamiltonian5 = Hamiltonian(EulerPlot5)

plt.plot(EulerHamiltonian1[:,1],EulerHamiltonian1[:,0],"-c", label = "h = 0.1 s")
plt.plot(EulerHamiltonian2[:,1],EulerHamiltonian2[:,0],"-r", label = "h = 0.01 s")
plt.plot(EulerHamiltonian3[:,1],EulerHamiltonian3[:,0],"-g", label = "h = 0.001 s")
plt.plot(EulerHamiltonian4[:,1],EulerHamiltonian4[:,0],"-b", label = "h = 0.0001 s")
plt.plot(EulerHamiltonian5[:,1],EulerHamiltonian5[:,0],"-k", label = "h = 0.00001 s")
plt.legend(loc='upper left')
plt.ylabel("Total energy (J)")
plt.xlabel("Time (s)")
plt.show()