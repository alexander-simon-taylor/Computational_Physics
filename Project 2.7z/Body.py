import numpy as np
import matplotlib.pyplot as plt
import math

# k = 1.76 N/m, m = 3.31 kg, b_crit = 4.827 kg/s

def isValidInput(a,b): # Function to use to check inputs are valid
    inputOutput = 1
    try: # Checks whether inputs are numbers
        a = float(a) # This is the only check for x0 and v0, as they can be positive or negative.
        if b == 1: # Used for m and k, which cannot equal 0.
            if a <= 0:
                inputOutput = 0
        if b == 2: # Used for b, which can equal 0, but not less than 0.
            if a < 0:
                inputOutput = 0
    except:
        inputOutput = 0
    return inputOutput

def ForceArray(dt,n): # A function to call to add forcing to the system, the interior of the function is modified as needed.
    ForceArray = np.zeros(n+1)
    #for i in range (0,n+1):
    #    ForceArray[i] = np.sin(i*dt*0.25)
    return ForceArray # Note that this function is not used to plot the resonance graph.

def Hamiltonian(SolutionArray): # This functions calculates the total energy of the system.
    HamiltonianArray = np.zeros((len(SolutionArray[:,0])-1,2)) # The -1 is due to Verlet's method not having a defined v for the final timestamp.
    TimeStamps = SolutionArray[:,2]
    HamiltonianArray[:,1] = TimeStamps[:-1] # The [:-1] shortens TimeStamps by one, due to the -1 problem mentioned above.
    for i in range(0,len(SolutionArray[:,0])-1):
        HamiltonianArray[i,0] = (k*SolutionArray[i,0]**2 + m*SolutionArray[i,1]**2)/2
    return HamiltonianArray

def EulerMethod(x0,v0,dt,n): # The Euler method.
    EulerArray = np.zeros((n+1,3))
    EulerArray[0] = [x0,v0,0] # The third column is for timestamps, hence the hardcoding as 0.
    Forcing = ForceArray(dt,n)
    for i in range(1,n+1):
        EulerArray[i,0] = EulerArray[i-1,0] + dt*EulerArray[i-1,1] # x-values.
        EulerArray[i,1] = EulerArray[i-1,1]*(1-b*dt/m) - dt*k*EulerArray[i-1,0]/m + dt*Forcing[i-1]/m # v-values.
        EulerArray[i,2] = i*dt # t-values.
    return EulerArray

def ImprovedEuler(x0,v0,dt,n): # The improved Euler method.
    ImprovedArray = np.zeros((n+1,3))
    ImprovedArray[0] = [x0,v0,0]
    Forcing = ForceArray(dt,n)
    for i in range(1,n+1):
        ImprovedArray[i,0] = ImprovedArray[i-1,0]*(1-k*dt**2/(2*m)) + ImprovedArray[i-1,1]*(dt - b*dt**2/(2*m)) + Forcing[i-1]*dt**2/(2*m) # x-values.
        ImprovedArray[i,1] = ImprovedArray[i-1,1]*(1-b*dt/m) - dt*k*ImprovedArray[i-1,0]/m + dt*Forcing[i-1]/m # v-values.
        ImprovedArray[i,2] = i*dt # t-values
    return ImprovedArray

def VerletMethod(x0,v0,dt,n): # Unsurprisingly, the Verlet method.
    VerletArray = np.zeros((n+1,3))
    VerletArray[0] = [x0,v0,0]
    Forcing = ForceArray(dt,n)
    VerletArray[1] = [x0 + dt*v0,0,dt] # Hard coded here for one step of Euler, otherwise any index dependent force switches for the forcing make the forcing function go out of index. v_1 = 0 doesn't matter here, since its calculation later overwrites this anyway.
    for i in range(2,n+1):
        VerletArray[i,0] = VerletArray[i-1,0]*2*(2*m - k*dt**2)/(2*m + b*dt) + VerletArray[i-2,0]*(b*dt - 2*m)/(b*dt + 2*m) + Forcing[i-1]*dt**2/m # x-values
        VerletArray[i-1,1] = (VerletArray[i,0] - VerletArray[i-2,0])/(2*dt) # v-values. This isn't needed to calculate the x-iterations, but makes this compatible with the Hamiltonian and phase space plots.
        VerletArray[i,2] = i*dt # t-values.
    return VerletArray

def EulerCromerMethod(x0,v0,dt,n): # As you guessed, the Euler-Cromer method.
    EulerCromerArray = np.zeros((n+1,3))
    EulerCromerArray[0] = [x0,v0,0]
    Forcing = ForceArray(dt,n)
    for i in range(1,n+1):
        EulerCromerArray[i,1] = EulerCromerArray[i-1,1]*(1-b*dt/m) - dt*k*EulerCromerArray[i-1,0]/m + Forcing[i]*dt/m # v-values.
        EulerCromerArray[i,0] = EulerCromerArray[i-1,0] + dt*EulerCromerArray[i,1] # x-values. Switching the order x and v are calulated simplifies the function massively.
        EulerCromerArray[i,2] = i*dt # t-values.
    return EulerCromerArray

def Analytical(x0,v0,dt,n): # Determines analytical solution values. As for the Verlet method, the v-values aren't needed for the simulation, but are for Hamiltonian and phase space plots.
    Analytical = np.zeros((n+1,3))
    Damping = np.ones(n+1)
    if b > 0: # If there is no damping, the exponentials don't need to be calculated.
        for i in range(0,n+1):
            Damping[i] *= np.exp(-b*i*dt/(2*m)) # By calculating the exponential term here, it only has to be done over one loop, otherwise it may have to be done multiple times per call.
    if b**2 < 4*k*m: # Light damping and no damping. The equation for no damping is the same as for light damping with b = 0, so that special case is not needed.
        omega = np.sqrt(k/m - (b/(2*m))**2)
        for i in range(0,n+1):
            Analytical[i,0] = Damping[i]*((v0/omega + b*x0/(2*m*omega))*np.sin(omega*i*dt) + x0*np.cos(omega*i*dt))
            Analytical[i,1] = -b*Analytical[i,0]/(2*m) + omega*Damping[i]*((v0/omega + b*x0/(2*m*omega))*np.cos(omega*i*dt) - x0*np.sin(omega*i*dt))
            Analytical[i,2] = i*dt
    elif b**2 > 4*k*m: # Heavy damping.
        alpha = np.sqrt((b/(2*m))**2 - k/m)
        for i in range(0,n+1):
            Analytical[i,0] = Damping[i]*((v0/alpha + b*x0/(2*m*alpha))*np.sinh(alpha*i*dt) + x0*np.cosh(alpha*i*dt))
            Analytical[i,1] = -b*Analytical[i,0]/(2*m) + alpha*Damping[i]*((v0/alpha + b*x0/(2*m*alpha))*np.cosh(alpha*i*dt) + x0*np.sinh(alpha*i*dt))
            Analytical[i,2] = i*dt
    elif b**2 == 4*k*m: # Critical damping. In reality this will almost never be called without engineering k and m specifically, but adding it covers all bases.
        for i in range(0,n+1):
            Analytical[i,0] = Damping[i]*(x0 + (v0 + b*x0/(2*m))*i*dt)
            Analytical[i,1] = -b*Analytical[i,0]/(2*m) + Damping[i]*(v0 + b*x0/(2*m))
            Analytical[i,2] = i*dt
    return Analytical

def AccuracyCheck(x0,v0,dt,n): # See first equation in method section for the use of this function.
    AnalyticalArray = Analytical(x0,v0,dt,n)
    ValidMethod = 0
    while ValidMethod == 0: # This checks the input, which is used to determine the function, is valid. While it isn't the while loop loops.
        InputMethod = input("Enter the following numbers to check the methods: 1 for Euler, 2 for Improved Euler, 3 for Verlet, 4 for Euler-Cromer.\n>> ")
        if isValidInput(InputMethod,1) == 1:
            InputMethod = float(InputMethod)
            if InputMethod == 1 or InputMethod == 2 or InputMethod == 3 or InputMethod == 4:
                ValidMethod = 1
    if InputMethod == 1:
        CheckArray = EulerMethod(x0,v0,dt,n)
    elif InputMethod == 2:
        CheckArray = ImprovedEuler(x0,v0,dt,n)
    elif InputMethod == 3:
        CheckArray = VerletMethod(x0,v0,dt,n)
    elif InputMethod == 4:
        CheckArray = EulerCromerMethod(x0,v0,dt,n)
    xDeviance = 0
    for i in range(0,n+1):
        xDeviance += (AnalyticalArray[i,0] - CheckArray[i,0])**2
    xDeviance = np.sqrt(xDeviance/(n+1)) # As in first equation in method section.
    return xDeviance

def Resonance(x0,v0,b0): # Generates resonance curve.
    n1 = 300 # h = 0.01 is hardcoded into this function, it gives a good balance of accuracy vs computing power, so n1 = 300 gives omega-max = 3 rad/s, while the resonant angular frequency is about 0.7 rad/s.
    b = b0 # Makes layering resonance curves far easier
    ResonanceArray = np.zeros((n1 + 1,2))
    for j in range(0,n1 + 1):
        VerletArray = np.zeros((10001,3))
        VerletArray[0] = [x0,v0,0]
        omega = 0.01*j
        SinArray = SinForce(0.01,10000,omega) # Forcing terms with the specific angular frequency.
        VerletArray[1] = [x0 + 0.01*v0,v0*(1-b*0.01/m) - 0.01*k*x0/m + 0.01*SinArray[0]/m,0.01] # Hard coded here otherwise any number inputs for the forcing make the forcing function go out of index.
        for i in range(2,10001):
            VerletArray[i,0] = VerletArray[i-1,0]*2*(2*m - k*0.01**2)/(2*m + b*0.01) + VerletArray[i-2,0]*(b*0.01 - 2*m)/(b*0.01 + 2*m) + SinArray[i-1]*0.01**2/m # x-values. No need for v-values or t-values here.
        DispMax = -math.inf # This way, the first x term considered is always larger, so no bad results occur no matter the initial conditions.
        for q in range(2000,10001): # Starting at 2000 prevents the initial weirdness from intefering with the results.
            if VerletArray[q,0] > DispMax: # Finds the maximum amplitude after the initial weirdness, which is what is plotted for a resonance curve.
                DispMax = VerletArray[q,0]
        ResonanceArray[j,:] = [0.01*j,DispMax] # [Angulary frequency, maximum amplitude at that angular frequency]
    return ResonanceArray

def SinForce(dt,n,omega): # This function is separate from the forcing one, because it needs to always contain the same function, and have omega as an input.
    ForceArray = np.zeros(n+1)
    for i in range (0,n+1):
        ForceArray[i] = np.sin(i*dt*omega)
    return ForceArray

def WriteToFile(SolutionArray): # Writes a given solution array to a file.
    FileName = input("Enter the name you wish to save the file under, including the .csv file extension.\n>> ")
    writeFile = open(FileName,"w")
    for i in range(0,len(SolutionArray)):
        writeFile.write(str(SolutionArray[i,0]) + "," + str(SolutionArray[i,1]) + "," + str(SolutionArray[i,2]))
        if i != (len(SolutionArray) - 1): # Stops an empty line being created at the end.
            writeFile.write("\n")
    writeFile.close()
    return 0

def ReadFromFile(): # Reads a .csv file (that's formatted as WriteToFile would) and converts it to a solution array.
    FileName = input("Enter the name of the .csv file you wish to read in, including its file extension.\n>> ")
    try: # Checking the file exists
        readFile = open(FileName,"r")
        opened = 1
    except:
        print("File could not be found, possibly wrong file name,directory, or file extension.")
        opened = 0
    if opened == 1:
        SolutionArray = np.array([]).reshape(0,3) # Makes an empty array of the right shape.
        for line in readFile:
            SplitUp = line.split(",")
            SplitUp[2] = SplitUp[2].strip('\n') # Removes the \n from each line, otherwise float(...) doesn't work.
            ArrayLine = np.array([float(SplitUp[0]),float(SplitUp[1]),float(SplitUp[2])])
            SolutionArray = np.vstack((SolutionArray,ArrayLine)) # np.vstack puts the array in the same shape the iterative method outputs in.
        readFile.close()
    return SolutionArray

# Taking initial velocity, position, and the parameters k and m, and feeding them into the isValidInput function.

kvalid = 0 # Spring constant.
while kvalid == 0:
    k = input("Enter a positive, non-zero value for the spring constant, k, in newtons per metre.\n>> ") # Interestingly, all SI unit names are common nouns, even ones named after people.
    if isValidInput(k,1) == 1:
        kvalid = 1
        k = float(k)

mvalid = 0 # Mass.
while mvalid == 0:
    m = input("Enter a positive, non-zero value for the mass of the oscillator, m, in kilogrammes.\n>> ")
    if isValidInput(m,1) == 1:
        mvalid = 1
        m = float(m)

bvalid = 0 # Damping constant.
while bvalid == 0:
    b = input("Enter a positive value for the damping constant of the oscillator, b, in kilogrammes per second.\n>> ")
    if isValidInput(b,2) == 1:
        bvalid = 1
        b = float(b)

xvalid = 0 # Initial displacement from equilibrium.
while xvalid == 0:
    x0 = input("Enter a value for the initial position of the oscillator, in metres.\n>> ")
    if isValidInput(x0,0) == 1:
        xvalid = 1
        x0 = float(x0)

vvalid = 0 # Initial velocity.
while vvalid == 0:
    v0 = input("Enter a value for the initial velocity of the oscillator, in metres per second.\n>> ")
    if isValidInput(v0,0) == 1:
        vvalid = 1
        v0 = float(v0)

#EulerPlot1 = EulerMethod(x0,v0,0.1,1000)
#EulerHamiltonian1 = Hamiltonian(EulerPlot1)

#EulerPlot2 = EulerMethod(x0,v0,0.01,10000)
#EulerHamiltonian2 = Hamiltonian(EulerPlot2)

#EulerPlot3 = EulerMethod(x0,v0,0.001,100000)
#EulerHamiltonian3 = Hamiltonian(EulerPlot3)

#EulerPlot4 = EulerMethod(x0,v0,0.0001,1000000)
#EulerHamiltonian4 = Hamiltonian(EulerPlot4)

#EulerPlot5 = EulerMethod(x0,v0,0.00001,10000000)
#EulerHamiltonian5 = Hamiltonian(EulerPlot5)

#ImprovedEulerPlot = ImprovedEuler(x0,v0,0.01,10000)
#ImprovedHamiltonian = Hamiltonian(ImprovedEulerPlot)

#VerletPlot = VerletMethod(x0,v0,0.001,100000)
#VerletHamiltonian = Hamiltonian(VerletPlot)

#WriteToFile(VerletPlot)

VerletPlot = ReadFromFile()
print(VerletPlot)

#EulerCromerPlot = EulerCromerMethod(x0,v0,0.01,10000)
#EulerCromerHamiltonian = Hamiltonian(EulerCromerPlot)

#AnalyticalPlot = Analytical(x0,v0,0.01,10000)
#AnalyticalHamiltonian = Hamiltonian(AnalyticalPlot)

#ResonancePlot = Resonance(x0,v0,b0) # This takes significantly longer than all the other functions combined to run, so commenting this out while testing other plots is advised.

#value = AccuracyCheck(x0,v0,0.00001,10000000)
#print(value)

#plt.gcf().clear() # Clears the plot to prevent ghost plot weirdness.

# Position-time plots

#plt.plot(EulerPlot2[:,2],EulerPlot2[:,0],"-b", label = "Euler method")
#plt.plot(ImprovedEulerPlot[:,2],ImprovedEulerPlot[:,0],"-k", label = "Improved Euler method")
plt.plot(VerletPlot[:,2],VerletPlot[:,0],"-g", label = "Verlet's method")
#plt.plot(EulerCromerPlot[:,2],EulerCromerPlot[:,0])
#plt.plot(AnalyticalPlot[:,2],AnalyticalPlot[:,0],"-r", label = "Analytical solution")


#plt.plot(VerletPlot[:,2],VerletPlot[:,0],"-b", label = "Undamped")
#plt.plot(VerletPlot[:,2],VerletPlot[:,0],"C1", label = "Light damping")
#plt.plot(VerletPlot[:,2],VerletPlot[:,0],"-g", label = "Critical damping")
#plt.plot(VerletPlot[:,2],VerletPlot[:,0],"-r", label = "Heavy damping")
plt.legend(loc='upper left')
plt.ylabel("Displacement from equilibrium (m)")
plt.xlabel("Time (s)")

# Energy-time plots

#plt.plot(EulerHamiltonian1[:,1],EulerHamiltonian1[:,0],"-c", label = "h = 0.1 s")
#plt.plot(EulerHamiltonian2[:,1],EulerHamiltonian2[:,0],"-r", label = "h = 0.01 s")
#plt.plot(EulerHamiltonian3[:,1],EulerHamiltonian3[:,0],"-g", label = "h = 0.001 s")
#plt.plot(EulerHamiltonian4[:,1],EulerHamiltonian4[:,0],"-b", label = "h = 0.0001 s")
#plt.plot(VerletHamiltonian[:,1],VerletHamiltonian[:,0])
#plt.legend(loc='upper left')
#plt.ylabel("Total energy (J)")
#plt.xlabel("Time (s)")

# Resonance plots

#plt.plot(ResonancePlot[:,0],ResonancePlot[:,1])
#plt.ylabel("Maximum amplitude (m)")
#plt.xlabel("Forcing angular frequency (rad/s)")

# Phase space plots

#plt.plot(VerletPlot[:,0],VerletPlot[:,1],"-g", label = "Verlet's method") # phase space plot
#plt.plot(AnalyticalPlot[:,0],AnalyticalPlot[:,1],"-r", label = "Analytical solution")
#plt.legend(loc='upper left')
#plt.ylabel("Velocity (m/s)")
#plt.xlabel("Displacement from equilibrium (m)")

plt.show()