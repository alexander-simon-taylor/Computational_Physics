import numpy as np
import matplotlib.pyplot as plt

def RandomSphereVector():
    R = 2.0 #Initial condition to get the while loop going.
    while R >= 1: # Regenerating the vector if R > 1, rejection criterea.
        u1 = np.random.uniform(-1,1) # The limits of np.random.uniform(-1,1) are [-1,1), but = -1 gets the value rejected, so this boils down to (-1,1), which is what is required
        u2 = np.random.uniform(-1,1)
        R = u1**2 + u2**2
    x = 2.0*u1*np.sqrt(1.0-R)
    y = 2.0*u2*np.sqrt(1.0-R)
    z = 1.0 - 2.0*R
    Coords = np.array([x,y,z])
    return Coords

def RandExponential(MFP):
    u = np.random.uniform()
    x = -MFP*np.log(u)
    return x

def MaterialScatterless():
    SigmaA = 0.6023 # Avagadro's number * 1 barn in cm^2
    SigmaS = 0.6023 # Avagadro's number * 1 barn in cm^2
    valid = 0
    while valid == 0:
        material = input("Enter the material you would like to use, either lead, water, or graphite.\n\n>> ")
        if material.lower() == "lead":
            SigmaA *= 0.158*11.35/207.2 # ^ *sigmaA*rho/M
            SigmaS *= 0
            valid = 1
        elif material.lower() == "water":
            SigmaA *= 0.6652*1.0/18.0
            SigmaS *= 0
            valid = 1
        elif material.lower() == "graphite":
            SigmaA *= 0.0045*1.67/12.0
            SigmaS *= 0
            valid = 1
        else:
            print("\nTry again.")
    Parameters = np.array([SigmaA,SigmaS])
    return Parameters

def RandomWalk(Parameters,T):
    MFP = 1/sum(Parameters)
    ProbA = Parameters[0]*MFP
    Coords = np.array([0.0,0.0,0.0])
    History = np.array([0.0,0.0,0.0])
    Step = 1
    kill = 0
    while kill == 0:
        if Step == 1:
            Coords[0] = RandExponential(MFP)
        else:
            Coords += RandomSphereVector()*RandExponential(MFP)
        History = np.vstack((History, Coords))
        if 0 <= Coords[0] <= T:
            u = np.random.uniform()
            if u < ProbA:
                kill = 1
            else:
                Step += 1
        elif Coords[0] < 0:
            kill = 2
        elif Coords[0] > T:
            kill = 3
    return Coords[0] # 1 implies absorbed, 2 for reflected, 3 for transmitted

material = MaterialScatterless()
thickness = 500
count = 100000
runs = np.array([])
for i in range(0,count):
    absorbpoint = RandomWalk(material,thickness) # retrives the final x-coordinate of the neutron.
    if absorbpoint < thickness:
        runs = np.append(runs,absorbpoint)

hist = np.histogram(runs)
print(hist)

plt.clf()
plt.hist(runs, bins='auto')  # arguments are passed to np.histogram
plt.title("Histogram with 'auto' bins")
plt.show()