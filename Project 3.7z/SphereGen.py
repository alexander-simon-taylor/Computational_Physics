import numpy as np
import matplotlib.pyplot as plt

def RandomSphereVector():
    R = 2.0 #Initial condition to get the while loop going.
    while R >= 1: # Regenerating the vector if R > 1, rejection criterea.
        u1 = np.random.uniform(-1,1) # The limits of np.random.uniform(-1,1) are [-1,1), but = -1 gets the value rejected, so this boils down to (-1,1), which is what is required
        u2 = np.random.uniform(-1,1)
        R = u1**2 + u2**2
    x = 2.0*u1*np.sqrt(1.0-R)
    y = 2.0*u2*np.sqrt(1.0-R)
    z = 1.0 - 2.0*R
    Coords = np.array([x,y,z])
    return Coords

def RandExponential(MFP): # Generates a random variable distributed by an exponential distribution.
    u = np.random.uniform()
    x = -MFP*np.log(u)
    return x

def Material(): # Allows the user to select that material the slab is made from.
    SigmaA = 0.6023 # Avagadro's number * 1 barn in cm^2
    SigmaS = 0.6023 # Avagadro's number * 1 barn in cm^2
    valid = 0
    while valid == 0:
        material = input("Enter the material you would like to use, either lead, water, or graphite.\n\n>> ")
        if material.lower() == "lead":
            SigmaA *= 0.158*11.35/207.2 # old value *sigmaA*rho/M
            SigmaS *= 11.221*11.35/207.2 # old value *sigmaS*rho/M
            valid = 1
        elif material.lower() == "water":
            SigmaA *= 0.6652*1.0/18.0
            SigmaS *= 103.0*1.0/18.0
            valid = 1
        elif material.lower() == "graphite":
            SigmaA *= 0.0045*1.67/12.0
            SigmaS *= 4.74*1.67/12.0
            valid = 1
        elif material.lower() == "waterscatterless":
            SigmaA *= 0.6652*1.0/18.0 # old value *sigmaA*rho/M
            SigmaS *= 0
            valid = 1
        else:
            print("\nTry again.")
    Parameters = np.array([SigmaA,SigmaS])
    print(Parameters)
    return Parameters

def RandomWalk(Parameters,T): # Parameteres from material function, T is the thickness of the slab
    MFP = 1/(sum(Parameters)) # Mean free path calculation
    ProbA = Parameters[0]*MFP # Absorption probability
    Coords = np.array([0.0,0.0,0.0]) # Records the position of the neutron
    History = np.array([0.0,0.0,0.0]) # Records all past positions of the neuton - used for the path plot.
    Step = 1 # Used to make the first direction non-random
    kill = 0 # While loop condition and allows detection of how the particle is killed
    while kill == 0:
        if Step == 1:
            Coords[0] = RandExponential(MFP) # First step only effects the x-coordinate
        else:
            Coords += RandomSphereVector()*RandExponential(MFP) # Adding a random length random direction vector to the old position
        History = np.vstack((History, Coords)) # Recording all past positions
        if 0 <= Coords[0] <= T: # If the neutron is in the slab
            u = np.random.uniform()
            if u < ProbA: # Decides whether particle is absorbed
                kill = 1
            else:
                Step += 1 # The neutron survives, goes on for another step
        elif Coords[0] < 0: # If the neutron has been reflected
            kill = 2
        elif Coords[0] > T: # If the neutron has transmitted through.
            kill = 3
    return kill # 1 implies absorbed, 2 for reflected, 3 for transmitted

def WoodcockMaterial(): # Allows the use to select two materials to use with the Woodcock method
    SigmaA = np.array([0.6023,0.6023]) # Avagadro's number * 1 barn in cm^2
    SigmaS = np.array([0.6023,0.6023]) # Avagadro's number * 1 barn in cm^2
    valid = 0
    while valid == 0:
        material1 = input("Enter the first material you would like to use, either lead, water, or graphite.\n\n>> ")
        if material1.lower() == "lead":
            SigmaA[0] *= 0.158*11.35/207.2
            SigmaS[0] *= 11.221*11.35/207.2
            valid = 1
        elif material1.lower() == "water":
            SigmaA[0] *= 0.6652*1.0/18.0
            SigmaS[0] *= 103.0*1.0/18.0
            valid = 1
        elif material1.lower() == "graphite":
            SigmaA[0] *= 0.0045*1.67/12.0
            SigmaS[0] *= 4.74*1.67/12.0
            valid = 1
        else:
            print("\nTry again.")
    valid = 0
    while valid == 0:
        thickness1 = input("Enter a thickness for the first material you have chosen.\n\n>> ")
        try:
            thickness1 = float(thickness1)
            if thickness1 > 0:
                valid = 1
        except:
            print("\nPlease enter a positive number for the thickness.")
    valid = 0
    while valid == 0:
        material2 = input("Enter the second material you would like to use, either lead, water, or graphite.\n\n>> ")
        if material1.lower() == material2.lower():
            MatCheck = 0
            MatYes = 0
            while MatCheck == 0: # Confirms whether the choice to use two materials is deliberate
                SameMat = input("Please note you are using the same material twice. Are you sure you wish to continue? (Y/N)\n\n>> ")
                if SameMat.lower() == "y":
                    MatCheck = 1
                    MatYes = 1
                elif SameMat.lower() == "n":
                    MatCheck = 1
                else:
                    print("\nTry again.")
        else:
            MatYes = 1
        if material2.lower() == "lead" and MatYes == 1:
            SigmaA[1] *= 0.158*11.35/207.2
            SigmaS[1] *= 11.221*11.35/207.2
            valid = 1
        elif material2.lower() == "water" and MatYes == 1:
            SigmaA[1] *= 0.6652*1.0/18.0
            SigmaS[1] *= 103.0*1.0/18.0
            valid = 1
        elif material2.lower() == "graphite" and MatYes == 1:
            SigmaA[1] *= 0.0045*1.67/12.0
            SigmaS[1] *= 4.74*1.67/12.0
            valid = 1
        else:
                print("\nTry again.")
    valid = 0
    while valid == 0:
        thickness2 = input("Enter a thickness for the second material you have chosen.\n\n>> ")
        try:
            thickness2 = float(thickness1)
            if thickness2 > 0:
                valid = 1
        except:
            print("\nPlease enter a non-zero, positive number for the thickness.")
    thicknesses = np.array([thickness1,thickness2])
    output = np.array([SigmaA,SigmaS,thicknesses])
    return output
    # Now all the parameters are set.
    
def WoodcockWalk(inputs): # Completes a random walk with the Woodcock method
    SigmaA = inputs[0]
    SigmaS = inputs[1]
    thickness1 = inputs[2,0]
    thickness2 = inputs[2,1]
    if SigmaA[0] + SigmaS[0] > SigmaA[1] + SigmaS[1]: # First section has high Sigma, so low MFP, second section has fictitious steps
        Parameters = SigmaA[0] + SigmaS[0]
        check = 1
    else: # Second section has high Sigma, so low MFP
        Parameters = SigmaA[1] + SigmaS[1]
        check = 2
    MFP = 1/Parameters
    ProbA1 = SigmaA[0]/(SigmaA[0] + SigmaS[0]) # Probability of absorption in the first material
    ProbA2 = SigmaA[1]/(SigmaA[1] + SigmaS[1]) # Probability of absorption in the second material
    Coords = np.array([0.0,0.0,0.0])
    History = np.array([0.0,0.0,0.0])
    Step = 1
    kill = 0
    FicStepP = 1 - (sum(SigmaA) + sum(SigmaS) - Parameters)/Parameters # Probability a step is fictional
    while kill == 0:
        noabsorb = 0 # Check for fictious step later
        if Step == 1:
            v = np.array([1,0,0])
        elif (0 <= Coords[0] <= thickness1 and check == 2) or (thickness1 < Coords[0] <= thickness2 + thickness1 and check == 1): # If the neutron is in the section with the high MFP
            u = np.random.uniform()
            if u > FicStepP: # i.e. if the step isn't fictional. If it is fictional, v doesn't get re-calculated, so the direction stays the same.
                v = RandomSphereVector()
            else: # If the step is fictional
                noabsorb = 1 # Prevents fictitious steps being followed by absorption
        else:
            v = RandomSphereVector()
        Coords += v*RandExponential(MFP)
        History = np.vstack((History, Coords))
        if Coords[0] < 0: # If the neutron is to the left of the materials
            kill = 2 # Reflected
        elif Coords[0] > thickness1 + thickness2: # If the neutron is to the right of the materials
            kill = 3 # Transmitted
        elif Coords[0] <= thickness1 and noabsorb == 0: # If the neutron is in the first material and isn't a fictious step
            q = np.random.uniform()
            if q < ProbA1:
                kill = 1 # Absorbed
            else:
                Step += 1
        elif noabsorb == 0: # If the neutron is in the second material and isn't a fictious step
            q = np.random.uniform()
            if q < ProbA2:
                kill = 1 # Absorbed
            else:
                Step += 1
    return kill # 1 implies absorbed, 2 for reflected, 3 for transmitted

def Probabilities(thickness,nperrun): # Uses a single slab of material, and iterates to determine the number reflected, absorbed, or transmitted
    NArray = np.array([0,0,0])
    for i in range(0,(nperrun)):
        result = RandomWalk(material,thickness) - 1 # 0 for absorbed, 1 for reflected, 2 for transmitted
        NArray[result] += 1
    return NArray

def WCProbabilities(nperrun): # Uses a single slab of material, and iterates to determine the number reflected, absorbed, or transmitted
    NArray = np.array([0,0,0])
    for i in range(0,(nperrun)):
        result = WoodcockWalk(material) - 1 # 0 for absorbed, 1 for reflected, 2 for transmitted
        NArray[result] += 1
    return NArray

def Attenuation(maxthickness,nperrun,nruns):
    plotable = np.array([]).reshape(0,4)
    deltathickness = maxthickness/(nruns - 1)
    for i in range(1,nruns):
        onerun = Probabilities(i*deltathickness,nperrun)
        if onerun[2] > 0: # If there are more than 0 transmitted neutrons
            plotableline = np.zeros(4)
            plotableline[0] = i*deltathickness
            plotableline[1] = np.log(onerun[2]/nperrun)
            plotableline[2] = np.sqrt((nperrun*onerun[2])/(nperrun - onerun[2])) # This is the weight for polyfit, not the uncertainty.
            plotableline[3] = 1/plotableline[2] # This gives the uncertainty in order to plot error bar graphs
            plotable = np.vstack((plotable,plotableline))        
    bestlinefitfull = np.polyfit(plotable[:,0],plotable[:,1],1,w=plotable[:,2],full = "true") # Finds the best fit line using the method of least squares.
    bestfitline = bestlinefitfull[0] # Coefficients of the line of best fit
    chisq = bestlinefitfull[1]/(len(plotable)-2)
    uncertainty = np.polyfit(plotable[:,0],plotable[:,1],1,w=plotable[:,2],cov = "true")[1][0][0] # Finds the best fit line using the method of least squares.
    uncertainty = np.sqrt(uncertainty)/bestfitline[0]**2
    plt.clf()
    plt.errorbar(plotable[:,0],plotable[:,1],yerr=plotable[:,3],fmt=".")
    x = np.linspace(0,maxthickness,50000)
    y = bestfitline[0]*x + bestfitline[1]
    plt.plot(x,y)
    plt.xlabel("Thickness (cm)")
    plt.ylabel("ln(proportion of transmitted neutrons)")
    plt.show()
    MAC = -1/bestfitline[0]
    print(MAC)
    print(uncertainty)
    print(chisq)
    return plotable

material = WoodcockMaterial()
result = WCProbabilities(100000)

#material = Material()
#Attenuation(250,10000,100)
#result = Probabilities(10,100000)
print(result)