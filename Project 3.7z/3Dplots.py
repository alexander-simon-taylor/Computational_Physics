import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d import Axes3D

def UniformScatter(n): # Creates a 3-d grid of uniformly scattered points.
    coordinates = np.array([]).reshape(0,3)
    for i in range(0,n):
        x = np.random.uniform()
        y = np.random.uniform()
        z = np.random.uniform()
        position = np.array([x,y,z])
        coordinates = np.vstack((coordinates,position))
    return coordinates

def RandomSphere(n): # Creates n isotropic unit vectors
    coordinates = np.zeros((n,3))
    for i in range(0,n):
        coordinates[i] = RandomSphereVector()
    return coordinates

def randssp(p,q): # Azimuthal -124 deg altitude 4 deg for lines
    m = pow(2, 31)
    a = pow(2, 16) + 3 # 65539
    c = 0
    x = 123456789
    r = np.zeros([p,q])
    for l in range (0, p):
        for k in range (0, q):
            x = np.mod(a*x + c, m)
            r[l, k] = x/m
    return r

def RandomSphereVector(): # Creates one random isotropic unit vector.
    R = 2.0 #Initial condition to get the while loop going.
    while R >= 1: # Regenerating the vector if R > 1, rejection criterea.
        u1 = np.random.uniform(-1,1) # The limits of np.random.uniform(-1,1) are [-1,1), but = -1 gets the value rejected, so this boils down to (-1,1), which is what is required
        u2 = np.random.uniform(-1,1)
        R = u1**2 + u2**2
    x = 2.0*u1*np.sqrt(1.0-R)
    y = 2.0*u2*np.sqrt(1.0-R)
    z = 1.0 - 2.0*R
    Coords = np.array([x,y,z])
    return Coords

def RandExponential(MFP):
    u = np.random.uniform()
    x = -MFP*np.log(u)
    return x

def SphereScatter(MFP,n): # Plots vectors directionally uniformly distributed over the sphere, with lengths according to an exponential distribution.
    coords = np.zeros((n,3))
    for i in range(0,n):
        coords[i] = RandomSphereVector()*RandExponential(MFP)
    return coords

def Material(): # Same as in previous file
    SigmaA = 0.6023 # Avagadro's number * 1 barn in cm^2
    SigmaS = 0.6023 # Avagadro's number * 1 barn in cm^2
    valid = 0
    while valid == 0:
        material = input("Enter the material you would like to use, either lead, water, or graphite.\n\n>> ")
        if material.lower() == "lead":
            SigmaA *= 0.158*11.35/207.2 # ^ *sigmaA*rho/M
            SigmaS *= 11.221*11.35/207.2
            valid = 1
        elif material.lower() == "water":
            SigmaA *= 0.6652*1.0/18.0
            SigmaS *= 103.0*1.0/18.0
            valid = 1
        elif material.lower() == "graphite":
            SigmaA *= 0.0045*1.67/12.0
            SigmaS *= 4.74*1.67/12.0
            valid = 1
        elif material.lower() == "waterscatterless":
            SigmaA *= 0.6652*1.0/18.0
            SigmaS = 0
            valid = 1
        else:
            print("\nTry again.")
    Parameters = np.array([SigmaA,SigmaS])
    return Parameters

def RandomWalk(Parameters,T): # Same as in previous file
    MFP = 1/sum(Parameters)
    ProbA = Parameters[0]*MFP
    Coords = np.array([0.0,0.0,0.0])
    History = np.array([0.0,0.0,0.0])
    Step = 1
    kill = 0
    while kill == 0:
        if Step == 1:
            Coords[0] = RandExponential(MFP)
        else:
            Coords += RandomSphereVector()*RandExponential(MFP)
        History = np.vstack((History, Coords))
        if 0 <= Coords[0] <= T:
            u = np.random.uniform()
            if u < ProbA:
                kill = 1
            else:
                Step += 1
        elif Coords[0] < 0:
            kill = 2
        elif Coords[0] > T:
            kill = 3
    ResultArray = np.array([kill])
    return History

#coordinates = RandomSphere(2000)
material = Material()
coordinates = RandomWalk(material,20)
#coordinates = randssp(10000,3)
#coordinates = UniformScatter(10000)

fig = plt.figure()
plt.clf()
ax = fig.add_subplot(111, projection='3d')

ax.set_xlabel('x coordinate')
ax.set_ylabel('y coordinate')
ax.set_zlabel('z coordinate')

#ax.scatter(coordinates[:,0],coordinates[:,1],coordinates[:,2],marker=".")
ax.plot(coordinates[:,0],coordinates[:,1],coordinates[:,2],marker="o")
ax.plot([0],[0],[0],marker="o",color="r")
plt.show()